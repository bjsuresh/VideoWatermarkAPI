using Microsoft.AspNetCore.Mvc; // For ControllerBase, IActionResult, and attributes
using System.IO; // For File operations
using System.Threading.Tasks; // For async methods

[Route("[controller]")]

public class VideoController : ControllerBase
{
    private readonly VideoProcessor _videoProcessor;

    public VideoController()
    {
        // Update this path to point to your FFmpeg executable
        // string ffmpegPath = @"C:\Users\Admin\ffmpeg\bin\ffmpeg.exe";
        string ffmpegPath = @"C:\Users\Suresh\FFMPEG\bin\ffmpeg.exe";
        _videoProcessor = new VideoProcessor(ffmpegPath);
    }
    [HttpGet]
    public IActionResult Get()
    {
        return Ok("API is working!");
    }
    [HttpPost("add-watermark")]
    public async Task<IActionResult> AddWatermark(IFormFile videoFile, [FromForm] double latitude, [FromForm] double longitude)
    {
        string tempPath = Path.GetTempPath();
        string inputVideoPath = Path.Combine(tempPath, "videoFile");
        // string watermarkPath = Path.Combine(tempPath, watermarkImage.FileName);
        string outputVideoPath = Path.Combine(tempPath, $"watermark_{videoFile.FileName}");
        
        try
        {
            // Save uploaded files
            using (var stream = new FileStream(inputVideoPath, FileMode.Create))
            {
                await videoFile.CopyToAsync(stream);
            }
         
            string result = await _videoProcessor.AddRealtimeDatetimeOverlayAsync(inputVideoPath, outputVideoPath, latitude, longitude);
            Console.WriteLine($"Watermarked video saved at: {result},{outputVideoPath}");
            // Return processed video
            var videoBytes = await System.IO.File.ReadAllBytesAsync(result);
            return File(videoBytes, "video/mp4", Path.GetFileName(outputVideoPath));
        }
        catch (Exception ex)
        {
                Console.WriteLine($"Error: {ex.Message}");
            return BadRequest(ex.Message);
        }
        finally
        {
            // Clean up temporary files
            // if (System.IO.File.Exists(inputVideoPath)) System.IO.File.Delete(inputVideoPath);
            // if (System.IO.File.Exists(watermarkPath)) System.IO.File.Delete(watermarkPath);
            if (System.IO.File.Exists(outputVideoPath)) System.IO.File.Delete(outputVideoPath);
        }
    }
}
